HANDLE hDevice;

// ���峣��
#define SC_MANAGER_ACCESS (SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE | \
                          SC_MANAGER_ENUMERATE_SERVICE | SC_MANAGER_LOCK | \
                          SC_MANAGER_QUERY_LOCK_STATUS | SC_MANAGER_MODIFY_BOOT_CONFIG)

#define SERVICE_ACCESS (SERVICE_QUERY_CONFIG | SERVICE_CHANGE_CONFIG | \
                       SERVICE_QUERY_STATUS | SERVICE_ENUMERATE_DEPENDENTS | \
                       SERVICE_START | SERVICE_STOP | SERVICE_PAUSE_CONTINUE | \
                       SERVICE_INTERROGATE | SERVICE_USER_DEFINED_CONTROL)

#define IOCTL_IO_PauseProcess CTL_CODE(FILE_DEVICE_UNKNOWN, 0x807, METHOD_BUFFERED, FILE_ANY_ACCESS) //��ͣ����
#define IOCTL_IO_ResumeProcess		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x808, METHOD_BUFFERED, FILE_ANY_ACCESS) //�ָ�����

// ��װ��������ע�����
BOOL InstallDriver(LPCTSTR cszDriverName, LPCTSTR cszDriverFullPath) {
    if (!cszDriverName || !cszDriverFullPath ||
        !*cszDriverName || !*cszDriverFullPath) {
        return FALSE;
    }

    TCHAR szPath[MAX_PATH];
    _stprintf_s(szPath, _T("SYSTEM\\CurrentControlSet\\Services\\%s"), cszDriverName);

    HKEY hKey;
    DWORD dwDisposition;
    LONG lResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, szPath, 0, NULL,
        REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dwDisposition);
    if (lResult != ERROR_SUCCESS) {
        return FALSE;
    }

    BOOL bSuccess = FALSE;
    do {
        // ����DisplayName
        lResult = RegSetValueEx(hKey, _T("DisplayName"), 0, REG_SZ,
            (const BYTE*)cszDriverName,
            (DWORD)(_tcslen(cszDriverName) + 1) * sizeof(TCHAR));
        if (lResult != ERROR_SUCCESS) break;

        // ����ErrorControl
        DWORD dwErrorControl = 1;
        lResult = RegSetValueEx(hKey, _T("ErrorControl"), 0, REG_DWORD,
            (const BYTE*)&dwErrorControl, sizeof(DWORD));
        if (lResult != ERROR_SUCCESS) break;

        // ����ImagePath
        TCHAR szImagePath[MAX_PATH];
        _stprintf_s(szImagePath, _T("\\??\\%s"), cszDriverFullPath);
        lResult = RegSetValueEx(hKey, _T("ImagePath"), 0, REG_SZ,
            (const BYTE*)szImagePath,
            (DWORD)(_tcslen(szImagePath) + 1) * sizeof(TCHAR));
        if (lResult != ERROR_SUCCESS) break;

        // ����Start
        DWORD dwStart = 3;
        lResult = RegSetValueEx(hKey, _T("Start"), 0, REG_DWORD,
            (const BYTE*)&dwStart, sizeof(DWORD));
        if (lResult != ERROR_SUCCESS) break;

        // ����Type
        DWORD dwType = 1;
        lResult = RegSetValueEx(hKey, _T("Type"), 0, REG_DWORD,
            (const BYTE*)&dwType, sizeof(DWORD));
        if (lResult != ERROR_SUCCESS) break;

        bSuccess = TRUE;
    } while (0);

    RegCloseKey(hKey);
    return bSuccess;
}

// ������������
BOOL CreateDriver(LPCTSTR cszDriverName, LPCTSTR cszDriverFullPath) {
    SC_HANDLE schManager = OpenSCManager(NULL, NULL, SC_MANAGER_ACCESS);
    if (!schManager) {
        return FALSE;
    }

    SC_HANDLE schService = OpenService(schManager, cszDriverName, SERVICE_ACCESS);
    if (schService) {
        SERVICE_STATUS svcStatus;
        // �����������������ֹͣ
        if (ControlService(schService, SERVICE_CONTROL_STOP, &svcStatus)) {
            if (svcStatus.dwCurrentState != SERVICE_STOPPED) {
                // �ȴ�����ֹͣ
                for (int i = 0; i < 10; i++) {
                    QueryServiceStatus(schService, &svcStatus);
                    if (svcStatus.dwCurrentState == SERVICE_STOPPED) {
                        break;
                    }
                    Sleep(4000);
                }
            }
        }
        CloseServiceHandle(schService);
        CloseServiceHandle(schManager);
        return TRUE;
    }

    // �����·���
    schService = CreateService(
        schManager,                  // SCManager���
        cszDriverName,                // ������
        cszDriverName,                // ��ʾ��
        SERVICE_ACCESS,               // ����Ȩ��
        SERVICE_KERNEL_DRIVER,        // ��������
        SERVICE_DEMAND_START,         // ��������
        SERVICE_ERROR_NORMAL,         // �������
        cszDriverFullPath,            // ����·��
        NULL,                         // ������
        NULL,                         // ��ǩID
        NULL,                         // ������
        NULL,                         // �˻���
        NULL                          // ����
    );

    if (!schService) {
        CloseServiceHandle(schManager);
        return FALSE;
    }

    CloseServiceHandle(schService);
    CloseServiceHandle(schManager);
    return TRUE;
}

// ������������
BOOL StartDriver(LPCTSTR cszDriverName, LPCTSTR cszDriverFullPath) {
    if (!cszDriverName || !*cszDriverName) {
        return FALSE;
    }

    if (!CreateDriver(cszDriverName, cszDriverFullPath)) {
        std::cout << "[-] CreateDriver ���ô��� ������� : " << GetLastError() << std::endl;
        return FALSE;
    }
    
    SC_HANDLE schManager = OpenSCManager(NULL, NULL, SC_MANAGER_ACCESS);
    if (!schManager) {
        std::cout << "[-] OpenSCManager ���ô��� ������� : " << GetLastError() << std::endl;
        return FALSE;
    }
    std::cout << "[+] OpenSCManager ���ý�� : " << schManager << std::endl;
    SC_HANDLE schService = OpenService(schManager, cszDriverName, SERVICE_ACCESS);
    if (!schService) {
        std::cout << "[-] OpenService ���ô��� ������� : " << GetLastError() << std::endl;
        CloseServiceHandle(schManager);
        return FALSE;
    }
    std::cout << "[+] OpenService ���ý�� : " << schService << std::endl;
    SERVICE_STATUS svcStatus;
    BOOL bSuccess = FALSE;

    // �������Ƿ���������
    if (QueryServiceStatus(schService, &svcStatus)) {
        if (svcStatus.dwCurrentState == SERVICE_RUNNING) {
            bSuccess = TRUE;
        }
    }

    if (!bSuccess) {
        // ��������
        if (StartServiceA(schService, 0, NULL)) {
            // �ȴ���������
            for (int i = 0; i < 10; i++) {
                QueryServiceStatus(schService, &svcStatus);
                if (svcStatus.dwCurrentState == SERVICE_RUNNING) {
                    bSuccess = TRUE;
                    break;
                }
                Sleep(4000);
            }
        }
        std::cout << "[-] StartService ���ý������ : " << GetLastError() << std::endl;
    }

    CloseServiceHandle(schService);
    CloseServiceHandle(schManager);
    
    return bSuccess;
}

// ֹͣ��������
BOOL StopDriver(LPCTSTR cszDriverName, LPCTSTR) {
    SC_HANDLE schManager = OpenSCManager(NULL, NULL, SC_MANAGER_ACCESS);
    if (!schManager) {
        return FALSE;
    }
    SC_HANDLE schService = OpenService(schManager, cszDriverName, SERVICE_ACCESS);
    if (!schService) {
        CloseServiceHandle(schManager);
        return FALSE;
    }
    BOOL bSuccess = TRUE;
    SERVICE_STATUS svcStatus;

    // �������Ƿ�������
    if (QueryServiceStatus(schService, &svcStatus)) {
        if (svcStatus.dwCurrentState != SERVICE_STOPPED) {
            // ֹͣ����
            if (ControlService(schService, SERVICE_CONTROL_STOP, &svcStatus)) {
                // �ȴ�����ֹͣ
                for (int i = 0; i < 10; i++) {
                    QueryServiceStatus(schService, &svcStatus);
                    if (svcStatus.dwCurrentState == SERVICE_STOPPED) {
                        break;
                    }
                    Sleep(4000);
                }

                // ���ռ��״̬
                if (svcStatus.dwCurrentState != SERVICE_STOPPED) {
                    bSuccess = FALSE;
                }
            }
            else {
                bSuccess = FALSE;
            }
        }
    }
    else {
        bSuccess = FALSE;
    }

    CloseServiceHandle(schService);
    CloseServiceHandle(schManager);
    return bSuccess;
}

// �Ƴ�����ע�����
BOOL RemoveDriver(LPCTSTR cszDriverName) {
    TCHAR szPath[MAX_PATH];
    _stprintf_s(szPath, _T("SYSTEM\\CurrentControlSet\\Services\\%s"), cszDriverName);

    HKEY hKey;
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, szPath, 0, KEY_WRITE, &hKey) != ERROR_SUCCESS) {
        return FALSE;
    }

    BOOL bSuccess = TRUE;
    const TCHAR* values[] = {
        _T("DisplayName"),
        _T("ErrorControl"),
        _T("ImagePath"),
        _T("Start"),
        _T("Type")
    };

    for (int i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
        if (RegDeleteValue(hKey, values[i]) != ERROR_SUCCESS) {
            bSuccess = FALSE;
            break;
        }
    }

    RegCloseKey(hKey);

    // ����ɾ�����������
    RegDeleteKey(HKEY_LOCAL_MACHINE, szPath);

    return bSuccess;
}

// ��װ����������
BOOL InstallProcessDriver() {
    LPCTSTR driverName = _T("Debug"); //extFunction(m_DrvPaht, L".sys", L"", 0, 1, false).c_str();
    LPCTSTR driverPath = m_DrvPaht.c_str();//_T("C:\\Users\\Mono\\source\\repos\\AntiPro\\AntiPro\\Debug.sys");// �������·��
    // ��װ��������
    //InstallDriver(driverName, driverPath);
    InstallDriver(driverName, driverPath);
    // ��������
    BOOL ret = StartDriver(driverName, driverPath);
    // ���ʧ��������
    if (!ret) {
        std::cout << "[+] ���ش���" << std::endl;
        StopDriver(driverName, driverPath);
        RemoveDriver(driverName);
        InstallDriver(driverName, driverPath);
        ret = StartDriver(driverName, driverPath);
    }
    hDevice = CreateFileA("\\\\.\\Test64", GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 128, 0);
    return ret;
}

HANDLE GetDrvHandle() 
{
    hDevice = CreateFileA("\\\\.\\Test64", GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 128, 0);
    return hDevice;
}

void Pause(DWORD ProcessID)
{
    DWORD bytesReturned = 0;
    BOOL success = DeviceIoControl(
        hDevice,                    // �豸���
        IOCTL_IO_PauseProcess,      // ������
        &ProcessID,                       // ���뻺����������ID��
        sizeof(DWORD),              // ���뻺������С
        nullptr,                    // ���������
        0,                          // �����������С
        &bytesReturned,             // �����ֽ���
        nullptr                     // �ص�������ͬ��������Ϊnull��
    );
}

void Resume(DWORD ProcessID)
{
    DWORD bytesReturned = 0;
    BOOL success = DeviceIoControl(
        hDevice,                    // �豸���
        IOCTL_IO_ResumeProcess,      // ������
        &ProcessID,                       // ���뻺����������ID��
        sizeof(DWORD),              // ���뻺������С
        nullptr,                    // ���������
        0,                          // �����������С
        &bytesReturned,             // �����ֽ���
        nullptr                     // �ص�������ͬ��������Ϊnull��
    );
}