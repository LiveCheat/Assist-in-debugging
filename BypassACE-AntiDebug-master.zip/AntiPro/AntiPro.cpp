﻿#include <iostream>
#include <Windows.h>
#include <tchar.h>
#include <string>
#include <vector>
#include "变量声明.h"
#include "其他功能类.h"
#include "ProcessDriver.h"
//遍历窗口句柄 Cheat Engine / 必须遍历出两个窗口句柄
BOOL FindCheatHwnd() 
{
	for (size_t i = 0; i < 1500000; i++)
	{
		if (IsWindow((HWND)i) != 0)//判断窗口是否有效
		{
			DWORD g_pid = NULL;
			GetWindowThreadProcessId((HWND)i, &g_pid);
			if ((int)g_pid == CheatEnginePid) {
				int len = GetWindowTextLength((HWND)i) + 1; //为下面的缓冲区准备长度
				char* title = new char[len]; //分配缓冲区预存储标题
				GetWindowTextA((HWND)i, title, len);

				size_t Findlen = TextFind(title, "GhostStudio", 0);
				if (Findlen < 1000 && Findlen > 0)
				{
					std::cout << "[+] 遍历到的 Cheat Engine 窗口句柄->" << i << std::endl;
					hWndArray.push_back((HWND)i);
				}
				delete[] title;
			}
		}
	}
	std::cout << " " << std::endl;
	std::cout << "[+] 进程窗口遍历完成 !" << std::endl;
	if (hWndArray.size() == 2) return true;
	return false;
}

void AntiMain() 
{
	SetConsoleTitleA("BypassACE - AntiDebug/ QQ群:892857562");

	MessageBoxA(0, "Anti ACE Debug 已运行", "", 0);

	std::cout << "是否加载破虚拟化驱动 ? (小写)[yes/no]";
	std::string g_VirtualLogic;
	std::cin >> g_VirtualLogic;
	if (g_VirtualLogic == "yes")
	{
		std::cout << "请输入你需要加载的驱动路径 [ 例如 : C:\\虚拟化.sys ] : ";
		std::string g_Virtual;
		std::cin >> g_Virtual;
		m_Virtual = StringToWstring(g_Virtual);
		InstallDriver(L"VirtualDrievr", m_Virtual.c_str());
		// 启动驱动
		BOOL ret = StartDriver(L"VirtualDrievr", m_Virtual.c_str());
		// 如果失败则重试
		if (!ret) {
			std::cout << "[+] 加载错误" << std::endl;
			StopDriver(L"VirtualDrievr", m_Virtual.c_str());
			RemoveDriver(L"VirtualDrievr");
			InstallDriver(L"VirtualDrievr", m_Virtual.c_str());
		}
		if (ret == true)
		{
			std::cout << "[+] 虚拟化驱动加载成功 ! 驱动启动状态-> 1" << std::endl;
		}
	}

	std::cout << "是否更改默认驱动加载路径 当前驱动路径:C:\\Windows\\Debug.sys(小写)[yes/no]";
	std::string PathLogic;
	std::cin >> PathLogic;
	if (PathLogic == "yes") {
		std::cout << "请输入你需要更改的驱动路径 [ 例如 : C:\\Debug.sys ] : ";
		std::string InputPath;
		std::cin >> InputPath;
		m_DrvPaht = StringToWstring(InputPath);
	}
	int DrvLogin = InstallProcessDriver();
	std::cout << "Driver Load Status : " << DrvLogin << std::endl;
	if (DrvLogin == 0)
	{
		StopDriver(m_DrvName, m_DrvPaht.c_str());
		RemoveDriver(m_DrvName);
		MessageBoxA(0, "点确定程序关闭", "", 0);
		return ;
	}
	std::cout << "[?] 是否以父进程创建进程(小写)[yes/no]";
	std::string g_str;
	std::cin >> g_str;
	if (g_str == "yes")
	{
		std::cout << "[!] 输入父进程进程ID : ";
		int g_WithParentPid = NULL;
		std::cin >> g_WithParentPid;
		std::cout << "[!] 输入Cheat Engine 的进程路径 : ";
		std::string g_PathText;
		std::cin >> g_PathText;
		// 创建转换器（UTF-8 到 wstring）
		LPCTSTR g_Path = string_to_wstring(g_PathText.c_str()).c_str();
		CreateProcessWithParent(g_WithParentPid, g_Path);
	}
	MessageBoxA(0, "点确定开始获取 Cheat Engine 的进程标识", "", 0);
	CheatEnginePid = GetProcessIdFromName(m_Name);
	std::cout << "[+] 获取到的进程标识 : " << CheatEnginePid << std::endl;

	bool FindStatus = FindCheatHwnd();

	if (FindStatus == false) MessageBoxA(0, "Cheat Engine 枚举失败 ! 请联系作者修改", "", 0);

	for (int g_i = 0; g_i < hWndArray.size(); g_i++)
	{
		std::srand(static_cast<unsigned int>(std::time(nullptr)));
		int g_rand = 42314 + std::rand() % (43254365 - 42314 + 1);
		std::string WindowText = std::to_string(g_rand);
		std::cout << "[+] 生成的随机数标题->" << WindowText << std::endl;
		SetWindowTextA(hWndArray[g_i], WindowText.c_str());
		SetWindowLongA(hWndArray[g_i], -20, 256);
		SetWindowLongA(hWndArray[g_i], -16, 349110272);
	}

	while (true)
	{
		InPutStatus = FALSE;
		std::cout << "[+] InPut GamePid [输入 3 退出程序 !] : ";
		int g_GamePid;
		std::cin >> g_GamePid;

		InPutStatus = TRUE;
		if (g_GamePid == 3) exit(1);
		Pause(g_GamePid);
		MessageBoxA(0, "进程已挂起", "", 0);
		if (InPutStatus == TRUE)
		{
			Resume(g_GamePid);
			MessageBoxA(0, "进程已恢复", "", 0);
		}
	}
	MessageBoxA(0,"函数已执行到尾部 点击确定重复执行该函数","",0);
	AntiMain();
}

int main()
{
	AntiMain();
	return 0;
}