int m_ProcessID = NULL, CheatEnginePid = NULL;

HWND m_HWMD = NULL;

BOOL InPutStatus = false;

const char* m_Name = "Mono_Cheat_Engine.exe";

LPCTSTR m_DrvName = L"Process";

std::wstring m_DrvPaht, m_Virtual;

std::vector<HWND> hWndArray;